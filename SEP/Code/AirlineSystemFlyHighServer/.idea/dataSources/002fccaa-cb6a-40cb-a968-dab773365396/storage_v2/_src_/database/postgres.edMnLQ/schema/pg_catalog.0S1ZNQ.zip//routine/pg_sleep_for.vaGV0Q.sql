CREATE FUNCTION pg_sleep_for(interval)
  RETURNS void
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.pg_sleep(extract(epoch from pg_catalog.clock_timestamp() operator(pg_catalog.+) $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))
$$;

