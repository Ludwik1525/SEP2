CREATE FUNCTION pg_file_length(text)
  RETURNS bigint
STRICT
LANGUAGE SQL
AS $$
SELECT size FROM pg_catalog.pg_stat_file($1)
$$;

